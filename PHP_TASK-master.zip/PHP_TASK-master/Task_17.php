<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <?php
        include_once 'fun.php'
    ?>
</head>
<body>
    <?php
        image('2.jpg');
        image('3.jpg');
    ?>
</body>
</html>