<?php
    print 'Kak tbl?';
    print "Otliichn0. ";
?>
