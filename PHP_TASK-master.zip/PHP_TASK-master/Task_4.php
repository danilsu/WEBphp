<?php
$first_name = "Artem";
$last_name = "Alexandrovskiy";

$full_name = $first_name . " " . $last_name;

echo strlen($full_name);
echo $full_name;
